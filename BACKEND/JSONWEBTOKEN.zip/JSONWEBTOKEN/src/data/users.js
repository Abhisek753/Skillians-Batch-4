const users=[
    {id:1,email:"abc@gamil.com"},
    {id:2,email:"dbe@gamil.com"},
    {id:3,email:"efg@gamil.com"},
]

module.exports=users;
